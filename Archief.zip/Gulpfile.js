// Coffeescript +1
require('coffee-script/register')
require('./gulpfile.coffee')

# YellowLeaf
### Awesome nodejs ftp library

Making an FTP client has never been so easy!
Fully compatible with every RCF1234 FTP client,
your server will impress users!
